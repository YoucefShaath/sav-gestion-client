var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.svg/route.js")
R.c("server/chunks/[root-of-the-server]__4e76e359._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/18f6e_next_faaf1c4d._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_icon_svg_route_actions_958385ae.js")
R.m(48641)
module.exports=R.m(48641).exports
