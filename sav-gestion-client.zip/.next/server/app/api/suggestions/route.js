var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/suggestions/route.js")
R.c("server/chunks/[root-of-the-server]__11832011._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/a4d16__next-internal_server_app_api_suggestions_route_actions_3127a6e1.js")
R.m(13221)
module.exports=R.m(13221).exports
