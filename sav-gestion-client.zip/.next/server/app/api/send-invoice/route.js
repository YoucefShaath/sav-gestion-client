var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-invoice/route.js")
R.c("server/chunks/[root-of-the-server]__0430802d._.js")
R.c("server/chunks/[root-of-the-server]__a47ff84c._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/a4d16__next-internal_server_app_api_send-invoice_route_actions_dbef9e61.js")
R.m(33500)
module.exports=R.m(33500).exports
