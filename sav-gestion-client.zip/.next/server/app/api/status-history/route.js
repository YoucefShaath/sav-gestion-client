var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/status-history/route.js")
R.c("server/chunks/[root-of-the-server]__84f7c8d9._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/a4d16__next-internal_server_app_api_status-history_route_actions_c3fef524.js")
R.m(14462)
module.exports=R.m(14462).exports
