var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/status/route.js")
R.c("server/chunks/[root-of-the-server]__2cf6f29f._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_api_status_route_actions_e65536e5.js")
R.m(67159)
module.exports=R.m(67159).exports
