var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/login/route.js")
R.c("server/chunks/[root-of-the-server]__1f04e7fa._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/18f6e_next_faaf1c4d._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_api_login_route_actions_b8d09b03.js")
R.m(72002)
module.exports=R.m(72002).exports
