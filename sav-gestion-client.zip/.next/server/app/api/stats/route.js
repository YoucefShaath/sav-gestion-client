var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/route.js")
R.c("server/chunks/[root-of-the-server]__5f6d9a1c._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_api_stats_route_actions_e5a697f6.js")
R.m(79183)
module.exports=R.m(79183).exports
