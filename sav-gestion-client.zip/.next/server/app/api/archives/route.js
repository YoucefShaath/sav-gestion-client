var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/archives/route.js")
R.c("server/chunks/[root-of-the-server]__2402fb3b._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_api_archives_route_actions_09e043ed.js")
R.m(47722)
module.exports=R.m(47722).exports
