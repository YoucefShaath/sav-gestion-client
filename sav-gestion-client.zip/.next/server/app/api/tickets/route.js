var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/route.js")
R.c("server/chunks/[root-of-the-server]__88eea7f7._.js")
R.c("server/chunks/18f6e_next_dist_esm_build_templates_app-route_d4e3727d.js")
R.c("server/chunks/[root-of-the-server]__a47ff84c._.js")
R.c("server/chunks/[root-of-the-server]__e5f61293._.js")
R.c("server/chunks/[root-of-the-server]__914862c0._.js")
R.c("server/chunks/sav-gestion-client__next-internal_server_app_api_tickets_route_actions_0393936d.js")
R.m(40073)
module.exports=R.m(40073).exports
