module.exports=[18175,(e,o,d)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_api_status-history_route_actions_c3fef524.js.map