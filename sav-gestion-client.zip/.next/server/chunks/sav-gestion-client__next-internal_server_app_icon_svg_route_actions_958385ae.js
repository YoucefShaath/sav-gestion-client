module.exports=[38493,(e,o,d)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_icon_svg_route_actions_958385ae.js.map