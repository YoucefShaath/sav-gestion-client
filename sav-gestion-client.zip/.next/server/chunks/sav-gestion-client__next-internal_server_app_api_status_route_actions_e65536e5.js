module.exports=[95895,(e,o,d)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_api_status_route_actions_e65536e5.js.map