module.exports=[50844,(e,o,d)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_api_archives_route_actions_09e043ed.js.map