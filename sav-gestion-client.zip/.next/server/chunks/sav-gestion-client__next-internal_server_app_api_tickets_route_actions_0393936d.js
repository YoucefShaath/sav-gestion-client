module.exports=[53105,(e,o,d)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_api_tickets_route_actions_0393936d.js.map