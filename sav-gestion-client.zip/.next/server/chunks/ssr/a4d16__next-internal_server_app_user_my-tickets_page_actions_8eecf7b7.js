module.exports=[9482,(a,b,c)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_user_my-tickets_page_actions_8eecf7b7.js.map