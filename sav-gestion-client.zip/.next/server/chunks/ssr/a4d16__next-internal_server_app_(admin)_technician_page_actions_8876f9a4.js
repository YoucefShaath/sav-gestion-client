module.exports=[33511,(a,b,c)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_%28admin%29_technician_page_actions_8876f9a4.js.map