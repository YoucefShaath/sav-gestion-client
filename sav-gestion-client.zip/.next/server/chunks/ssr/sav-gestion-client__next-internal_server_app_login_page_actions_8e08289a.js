module.exports=[10828,(a,b,c)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_login_page_actions_8e08289a.js.map