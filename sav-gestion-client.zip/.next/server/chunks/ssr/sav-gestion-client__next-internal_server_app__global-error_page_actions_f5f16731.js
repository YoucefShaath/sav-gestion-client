module.exports=[27353,(a,b,c)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app__global-error_page_actions_f5f16731.js.map