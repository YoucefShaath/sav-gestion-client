module.exports=[30903,a=>{a.v("/_next/static/media/icon.6aba74e3.svg")},85022,a=>{"use strict";let b={src:a.i(30903).default,width:32,height:32};a.s(["default",0,b])}];

//# sourceMappingURL=sav-gestion-client_src_app_0d6f12a0._.js.map