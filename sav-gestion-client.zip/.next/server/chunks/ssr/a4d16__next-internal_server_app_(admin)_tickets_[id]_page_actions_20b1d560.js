module.exports=[33577,(a,b,c)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_%28admin%29_tickets_%5Bid%5D_page_actions_20b1d560.js.map