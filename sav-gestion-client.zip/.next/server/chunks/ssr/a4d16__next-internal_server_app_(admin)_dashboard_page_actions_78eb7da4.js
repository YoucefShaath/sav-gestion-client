module.exports=[47258,(a,b,c)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_%28admin%29_dashboard_page_actions_78eb7da4.js.map