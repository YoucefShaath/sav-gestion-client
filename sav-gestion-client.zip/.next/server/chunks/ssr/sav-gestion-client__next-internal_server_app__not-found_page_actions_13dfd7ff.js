module.exports=[43147,(a,b,c)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app__not-found_page_actions_13dfd7ff.js.map