module.exports=[66578,(a,b,c)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_user_new-ticket_page_actions_58aeeaf3.js.map