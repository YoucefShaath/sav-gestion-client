module.exports=[76699,(a,b,c)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_entreprise_page_actions_5285e0ae.js.map