module.exports=[78823,(a,b,c)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_page_actions_bc027860.js.map