module.exports=[19257,a=>{"use strict";var b=a.i(44790);function c({children:a}){return(0,b.jsx)("div",{className:"bg-gray-50 min-h-screen",children:a})}a.s(["default",()=>c,"metadata",0,{title:"Suivi de réparation — Informatica",description:"Suivez l'état de votre réparation en temps réel"}])}];

//# sourceMappingURL=sav-gestion-client_src_app_track_layout_2b997f64.js.map