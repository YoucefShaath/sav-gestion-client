module.exports=[34754,(e,o,d)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_api_suggestions_route_actions_3127a6e1.js.map