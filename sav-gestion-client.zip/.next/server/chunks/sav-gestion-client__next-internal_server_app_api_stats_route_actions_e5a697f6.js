module.exports=[57888,(e,o,d)=>{}];

//# sourceMappingURL=sav-gestion-client__next-internal_server_app_api_stats_route_actions_e5a697f6.js.map