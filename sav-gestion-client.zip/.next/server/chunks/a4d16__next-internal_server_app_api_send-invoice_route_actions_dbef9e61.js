module.exports=[49418,(e,o,d)=>{}];

//# sourceMappingURL=a4d16__next-internal_server_app_api_send-invoice_route_actions_dbef9e61.js.map