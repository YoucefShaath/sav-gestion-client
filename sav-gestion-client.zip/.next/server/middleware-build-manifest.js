globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/728898f7ad61dc5f.js",
    "static/chunks/beabfec10c303a47.js",
    "static/chunks/4e4a1d217b12fe3b.js",
    "static/chunks/93b03978126a1849.js",
    "static/chunks/turbopack-8e373ffa056fef8f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];